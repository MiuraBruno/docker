v = []
i = 0
def fib(n):
    if n < 2:
        return 1
    else:
        return fib(n-1) + fib(n-2)
while True:
    v.append(fib(i))
    i = i + 1
